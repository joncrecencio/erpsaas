# Changelog

All Notable changes to `sped-cte` will be documented in this file.


## 1.1.0 primeira versão BETA (release 08/09/2016)

>### Added
- XSD versão 3.00

>### Deprecated
- Nothing

>### Fixed
- Nothing

>### Removed
- Nothing

>### Security
- Nothing
